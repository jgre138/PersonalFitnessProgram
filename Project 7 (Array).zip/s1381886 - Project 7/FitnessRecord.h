#pragma once
#include "Date.h"
#include <string>
using namespace std;

class FitnessRecord
{
private:
	double weight;
	string exerciseType;
	int workoutTime;
	Date date;
public:
	FitnessRecord();
	FitnessRecord(double weight, string exerciseType, int workoutTime, Date date);
	void setWeight(double weight);
	void setExerciseType(string exerciseType);
	void setWorkoutTime(int workoutTime);
	void setDate(Date date);
	double getWeight();
	string getExerciseType();
	int getWorkoutTime();
	Date getDate();
	 string print(double height);
};

