#pragma once
#include <string>
using namespace std;

class Date
{
private:
	int day, month, year;
	bool isValid(int month, int day, int year);
public:
	Date();
	Date(int month, int day, int year);
	void setDate(int month, int day, int year);
	int getDay();
	int getMonth();
	int getYear();
	string toString();
};

