#pragma once
#include "Date.h"
#include "FitnessRecord.h"
#include <string>
using namespace std;

class HealthTracker
{
private:
	string name;
	char gender;
	Date birthOfDate;
	double height;
	void printMenu();
	int getOption();
	int capacity, days;
	FitnessRecord* history;
public:
	HealthTracker();
	~HealthTracker();
	void inputData();
	void printHistoryData();
	void printRecentData();
	void exectute();
};

