#pragma once
#include <string>
#include <iostream>
using namespace std;

class Helper
{
public:
	template<typename D>
	static D getInput() {
		D value = 0;
		cin >> value;
		while (cin.fail() || value <= 0)
		{
			cout << "Invalid number, please try again: ";
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cin >> value;
		}
		return value;
	}
	template <>
	static char getInput() {
		char value;
		cin >> value;
		while (value != 'f' && value != 'm' && value != 'o'
			&& value != 'F' && value != 'M' && value != 'O') // allows for uppercase and lowercase
		{
			cout << "Invalid gender, please try again: ";
			cin.clear();
			cin.ignore(1000, '\n');
			cin >> value;
		}
		return value;
	}
	template <>
	static string getInput() { //Prevents a name with integers in them
		string data;
		while (true) {
			getline(cin, data);
			bool hasDigit = false;
			for (int index = 0; index < data.length(); index++) {
				if (isdigit(data.at(index))) {
					hasDigit = true;
					break;
				}
			}
			if (!hasDigit) {
				return data;   // valid input
			}
			cout << "Invalid input (no digits allowed). Try again: ";
		}
	}
	template<typename T>
	static T* resizeArray(T* arr, int oldSize) {
		T* newArr = new T[oldSize * 2];
		for (int i = 0; i < oldSize; ++i) {
			newArr[i] = arr[i];
		}
		delete[] arr;
		return newArr;
	}
};

